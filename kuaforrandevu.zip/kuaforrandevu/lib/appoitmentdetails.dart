import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:randevu/appoitment/appoitment.dart';

class UserAppointments extends StatefulWidget {
  const UserAppointments({super.key, required String appointmentId});

  @override
  _UserAppointmentsState createState() => _UserAppointmentsState();
}

class _UserAppointmentsState extends State<UserAppointments> {
  Stream<QuerySnapshot>? _userAppointmentsStream;
  User? _currentUser;

  @override
  void initState() {
    super.initState();
    _currentUser = FirebaseAuth.instance.currentUser;
    if (_currentUser != null) {
      _initUserAppointmentsStream(_currentUser!);
    } else {
      FirebaseAuth.instance.authStateChanges().listen((user) {
        if (user != null) {
          setState(() {
            _currentUser = user;
          });
          _initUserAppointmentsStream(user);
        }
      });
    }
  }

  void _initUserAppointmentsStream(User user) {
    setState(() {
      _userAppointmentsStream = FirebaseFirestore.instance
          .collection('randevular')
          .where('userId', isEqualTo: user.uid)
          .where('saat', isGreaterThan: Timestamp.now())
          .orderBy('tarih', descending: false)
          .snapshots();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Aldığınız Randevu'),
      ),
      body: _currentUser == null
          ? const Center(child: Text('Kullanıcı oturumu açık değil'))
          : StreamBuilder<QuerySnapshot>(
              stream: _userAppointmentsStream,
              builder: (context, appointmentsSnapshot) {
                if (appointmentsSnapshot.hasError) {
                  return Center(
                      child: Text(
                          'Bir hata oluştu: ${appointmentsSnapshot.error}'));
                }
                if (appointmentsSnapshot.connectionState ==
                    ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                final appointments = appointmentsSnapshot.data!.docs;
                if (appointments.isEmpty) {
                  return const Center(child: Text('Hiç randevunuz yok.'));
                }
                return ListView.builder(
                  itemCount: appointments.length,
                  itemBuilder: (context, index) {
                    final data =
                        appointments[index].data() as Map<String, dynamic>;
                    final randevuId = appointments[index].id;
                    final randevuSaat =
                        (data['saat'] as Timestamp).toDate().toLocal();
                    final doluMu = data['doluMu'];

                    return ListTile(
                      title: Text(
                        'Randevu Saati: ${TimeOfDay.fromDateTime(randevuSaat).format(context)}',
                      ),
                      subtitle: doluMu == null
                          ? const Text('Durum Belirsiz')
                          : doluMu
                              ? const Text('Dolu',
                                  style: TextStyle(color: Colors.red))
                              : const Text('Boş'),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _randevuSil(randevuId),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }

  Future<void> _randevuSil(String randevuId) async {
    final firestore = FirebaseFirestore.instance;
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Kullanıcı oturumu açık değil'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final documentSnapshot =
        await firestore.collection('randevular').doc(randevuId).get();
    final data = documentSnapshot.data() as Map<String, dynamic>;
    final randevuUserId = data['userId'];

    if (user.uid == randevuUserId) {
      try {
        await firestore.collection('randevular').doc(randevuId).delete();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Randevu başarıyla silindi.'),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => const Appointment(),
          ),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Randevu silinirken hata oluştu: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Bu randevuyu silme yetkiniz yok.'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
}
