import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:randevu/authentication/login.dart';
import 'package:randevu/services/auth_service.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({Key? key}) : super(key: key);

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _auth = AuthService();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController surnameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  bool isPasswordVisible = false;
  bool isConfirmPasswordVisible = false;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  @override
  void dispose() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    emailController.dispose();
    passwordController.dispose();
    nameController.dispose();
    surnameController.dispose();
    confirmPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('lib/assets/images/background.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            child: Form(
              key: formKey,
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      "Kayıt Ol",
                      style:
                          TextStyle(fontSize: 50, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 20),
                    buildTextFormField(nameController, "Ad", Icons.person),
                    const SizedBox(height: 10),
                    buildTextFormField(
                        surnameController, "Soyad", Icons.person),
                    const SizedBox(height: 10),
                    buildTextFormField(emailController, "E-posta", Icons.email),
                    const SizedBox(height: 10),
                    buildPasswordFormField(
                        passwordController, "Şifre", isPasswordVisible),
                    const SizedBox(height: 10),
                    buildPasswordFormField(confirmPasswordController,
                        "Şifre Tekrarı", isConfirmPasswordVisible),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: _signUp,
                      child: const Text("Kayıt Ol"),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text("Hesabınız mı var?"),
                        TextButton(
                          onPressed: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const LoginScreen()),
                            );
                          },
                          child: const Text("Giriş sayfasına dön"),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget buildTextFormField(
      TextEditingController controller, String hintText, IconData icon) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: TextFormField(
        controller: controller,
        validator: (value) {
          if (value!.isEmpty) {
            return "$hintText boş olamaz";
          }
          return null;
        },
        decoration: InputDecoration(
          icon: Icon(icon),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
          hintText: hintText,
        ),
      ),
    );
  }

  Widget buildPasswordFormField(
      TextEditingController controller, String hintText, bool isVisible) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: TextFormField(
        controller: controller,
        validator: (value) {
          if (value!.isEmpty) {
            return "$hintText boş olamaz";
          } else if (passwordController.text !=
                  confirmPasswordController.text &&
              hintText == "Şifre Tekrarı") {
            return "Şifreler eşleşmiyor";
          }
          return null;
        },
        obscureText: !isVisible,
        decoration: InputDecoration(
          icon: const Icon(Icons.lock),
          border: const OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(20.0))),
          hintText: hintText,
          suffixIcon: IconButton(
            onPressed: () {
              setState(() {
                if (hintText == "Şifre Tekrarı") {
                  isConfirmPasswordVisible = !isConfirmPasswordVisible;
                } else {
                  isPasswordVisible = !isPasswordVisible;
                }
              });
            },
            icon: Icon(isVisible ? Icons.visibility : Icons.visibility_off),
          ),
        ),
      ),
    );
  }

  void _signUp() async {
    if (formKey.currentState!.validate()) {
      try {
        final user = await _auth.createUserWithEmailAndPassword(
          nameController.text,
          surnameController.text,
          emailController.text,
          passwordController.text,
          confirmPasswordController.text,
        );

        if (user != null) {
          await FirebaseFirestore.instance
              .collection('users')
              .doc(user.uid)
              .set({
            'ad': nameController.text,
            'soyad': surnameController.text,
            'email': emailController.text,
          });

          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Kullanıcı başarıyla kaydedildi")),
          );

          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const LoginScreen()),
          );
        }
      } catch (e) {
        String errorMessage = e.toString();
        if (errorMessage.contains('email-already-in-use')) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Bu e-posta adresi zaten kullanımda")),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content:
                  Text("Kullanıcı eklenirken bir hata oluştu: ${e.toString()}"),
            ),
          );
        }
      }
    }
  }
}
