import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:randevu/adminprofile.dart';
import 'package:randevu/adminusers.dart';
import 'package:randevu/authentication/login.dart';

class AdminPage extends StatefulWidget {
  const AdminPage({super.key});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Paneli'),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text(
                'Admin İşlemleri',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.person),
              title: const Text('Kullanıcılar'),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const Adminusers()));
              },
            ),
            ListTile(
              leading: const Icon(Icons.settings),
              title: const Text('Profil'),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const ProfilePage()));
              },
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Çıkış Yap'),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const LoginScreen()));
              },
            )
          ],
        ),
      ),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance.collection('randevular').snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Bir hata oluştu: ${snapshot.error}'));
          }
          final randevular = snapshot.data!.docs;
          if (randevular.isEmpty) {
            return const Center(child: Text('Randevu bulunamadı.'));
          }

          // Randevuları tarihe göre gruplayarak sırala
          randevular.sort((a, b) {
            final tarihA = (a['tarih'] as Timestamp).toDate();
            final tarihB = (b['tarih'] as Timestamp).toDate();
            return tarihA.compareTo(tarihB);
          });

          return ListView.builder(
            itemCount: randevular.length,
            itemBuilder: (context, index) {
              final randevu = randevular[index];

              // Tarih ve saat değerlerini işle
              final tarihTimestamp = randevu['tarih'] as Timestamp;
              final DateTime tarih = tarihTimestamp.toDate();

              dynamic saatData = randevu['saat'];
              String saat;
              if (saatData is String) {
                saat = saatData;
              } else if (saatData is Timestamp) {
                saat = DateFormat.Hm().format(
                    saatData.toDate()); // DateFormat kullanarak formatlıyoruz
              } else {
                saat = 'Bilinmeyen Saat';
              }

              // Kullanıcı kimliğini al
              final userUid = randevu['userId'];
              return FutureBuilder<DocumentSnapshot>(
                future: FirebaseFirestore.instance
                    .collection('users')
                    .doc(userUid)
                    .get(),
                builder:
                    (context, AsyncSnapshot<DocumentSnapshot> userSnapshot) {
                  if (userSnapshot.connectionState == ConnectionState.waiting) {
                    return ListTile(
                      title: Text(
                          'Randevu Tarihi: ${DateFormat('dd-MM-yyyy').format(tarih)}'),
                      subtitle: Text(
                          'Randevu Saati: $saat, Kullanıcı: Yükleniyor...'),
                    );
                  }
                  if (userSnapshot.hasError ||
                      !userSnapshot.hasData ||
                      userSnapshot.data == null ||
                      userSnapshot.data!.data() == null) {
                    return ListTile(
                      title: Text(
                          'Randevu Tarihi: ${DateFormat('dd-MM-yyyy').format(tarih)}'),
                      subtitle:
                          Text('Randevu Saati: $saat, Kullanıcı: Bulunamadı'),
                    );
                  }
                  final userData =
                      userSnapshot.data!.data() as Map<String, dynamic>;
                  final ad = userData['ad'];
                  final soyad = userData['soyad'];
                  return Card(
                    margin:
                        const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                    child: ListTile(
                      title: Text(
                        'Randevu Tarihi: ${DateFormat('dd-MM-yyyy').format(tarih)}',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(
                        'Randevu Saati: $saat, Kullanıcı: $ad $soyad',
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
