import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:randevu/authentication/login.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await initializeDateFormatting('tr_TR');
    await Firebase.initializeApp(
      options: FirebaseOptions(
        apiKey: "AIzaSyBqS_qzzcCpewziimoNttZZ9EH2QkS545A",
        appId: "1:471802482364:web:4ec2281dcf7362f7890ab9",
        messagingSenderId: "471802482364",
        projectId: "modern-impulse-408012",
      ),
    );
  } catch (e) {
    print('Uygulama başlatılırken hata oluştu: $e');
  }

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginScreen(),
    );
  }
}
