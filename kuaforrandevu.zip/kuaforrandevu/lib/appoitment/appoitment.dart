import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:randevu/appoitmentdetails.dart';
import 'package:randevu/authentication/login.dart';
import 'package:randevu/drawer.dart';
import 'package:randevu/userprofile.dart';

class Appointment extends StatefulWidget {
  const Appointment({Key? key}) : super(key: key);

  @override
  State<Appointment> createState() => _AppointmentState();
}

class _AppointmentState extends State<Appointment> {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  TimeOfDay? _selectedTime;
  String? _userId;
  bool _hasExistingAppointment = false;

  @override
  void initState() {
    super.initState();
    _getCurrentUser();
  }

  void _getCurrentUser() {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      setState(() {
        _userId = user.uid;
      });
      _checkExistingAppointment(user.uid);
    }
  }

  void _checkExistingAppointment(String? userId) async {
    if (userId != null) {
      final querySnapshot = await FirebaseFirestore.instance
          .collection('randevular')
          .where('userId', isEqualTo: userId)
          .where('doluMu', isEqualTo: true)
          .get();
      setState(() {
        _hasExistingAppointment = querySnapshot.docs.isNotEmpty;
      });
    }
  }

  void _logOut() async {
    await FirebaseAuth.instance.signOut();
    setState(() {
      _userId = null;
      _hasExistingAppointment = false;
    });
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => const LoginScreen()));
  }

  void _goToProfilePage() {
    Navigator.push(context,
        MaterialPageRoute(builder: (context) => const ProfilePageUsers()));
  }

  void _goToAppointment() {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => const UserAppointments(
                  appointmentId: '',
                )));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue[400],
        title: const Text('Randevu Ekranı'),
      ),
      drawer: MyDrawer(
        onProfileTap: _goToProfilePage,
        onAppoitment: _goToAppointment,
        onSignOut: _logOut,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TableCalendar(
              firstDay: DateTime.utc(2020, 1, 1),
              lastDay: DateTime.utc(2030, 12, 31),
              focusedDay: _focusedDay,
              selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
              onDaySelected: (selectedDay, focusedDay) {
                setState(() {
                  _selectedDay = selectedDay;
                  _focusedDay = focusedDay;
                });
              },
              calendarFormat: CalendarFormat.month,
              onFormatChanged: (format) {},
              onPageChanged: (focusedDay) {
                _focusedDay = focusedDay;
              },
            ),
            const SizedBox(height: 1),
            ElevatedButton(
              onPressed:
                  _hasExistingAppointment ? null : () => _selectTime(context),
              child: const Text(
                "Randevu Ekle",
                textAlign: TextAlign.center,
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
              ),
            ),
            _selectedDay == null
                ? const Text('Lütfen bir gün seçin')
                : _buildAppointmentsList(),
          ],
        ),
      ),
    );
  }

  Widget _buildAppointmentsList() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('randevular')
          .where('tarih', isEqualTo: Timestamp.fromDate(_selectedDay!))
          .orderBy('saat', descending: false)
          .snapshots(),
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.hasError) {
          return Text('Hata: ${snapshot.error}');
        }

        if (snapshot.connectionState == ConnectionState.waiting) {
          return const CircularProgressIndicator();
        }

        final randevular = snapshot.data!.docs;

        if (randevular.isEmpty) {
          return const Text('Bu gün için hiç randevu yok.');
        }

        return DataTable(
          columns: const <DataColumn>[
            DataColumn(label: Text('Randevu Saati')),
            DataColumn(label: Text('Durum')),
            DataColumn(label: Text('İşlem')),
          ],
          rows: randevular.map((DocumentSnapshot document) {
            return _buildAppointmentRow(document);
          }).toList(),
        );
      },
    );
  }

  DataRow _buildAppointmentRow(DocumentSnapshot document) {
    final data = document.data() as Map<String, dynamic>;
    final appointmentId = document.id;
    final appointmentDateTime = (data['saat'] as Timestamp).toDate().toLocal();
    final formattedTime = DateFormat.Hm('tr_TR').format(appointmentDateTime);
    final isAppointmentFull = data['doluMu'];
    final appointmentUserId = data['userId'];

    return DataRow(cells: [
      DataCell(Text(
        'Randevu Saati: ${formattedTime}',
      )),
      DataCell(Text(
        isAppointmentFull == null
            ? 'Durum Belirsiz'
            : isAppointmentFull
                ? 'Dolu'
                : 'Boş',
        style: TextStyle(color: isAppointmentFull ? Colors.red : Colors.green),
      )),
      DataCell(
        _userId != null && _userId == appointmentUserId
            ? ElevatedButton(
                onPressed: () {
                  _deleteAppointment(appointmentId);
                },
                child: const Text("Randevuyu Sil"),
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    textStyle: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    )),
              )
            : const SizedBox.shrink(),
      ),
    ]);
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
      builder: (BuildContext context, Widget? child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: true),
          child: child!,
        );
      },
    );

    if (picked != null && _selectedDay != null) {
      final now = DateTime.now();
      final selectedDateTime = DateTime(
        _selectedDay!.year,
        _selectedDay!.month,
        _selectedDay!.day,
        picked.hour,
        picked.minute,
      );

      if (selectedDateTime.isBefore(now) ||
          (selectedDateTime.isAtSameMomentAs(now) && picked.hour < now.hour)) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content:
                Text('Geçmiş bir saat ve tarih için randevu oluşturamazsınız.'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }

      final selectedTimeWithInterval =
          TimeOfDay(hour: picked.hour, minute: 30 * (picked.minute ~/ 30));

      final isAppointmentExisting = await _checkAppointmentExistence(
          _selectedDay!, selectedTimeWithInterval);
      if (isAppointmentExisting) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
                'Bu saatte zaten bir randevu mevcut. Lütfen başka bir saat seçin.'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }

      setState(() {
        _selectedTime = selectedTimeWithInterval;
      });

      await _addAppointment(_selectedDay!, _selectedTime!);

      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(
            'Randevu alındı! Tarih: ${_selectedDay!.toLocal()}, Saat: ${_selectedTime!.format(context)}'),
      ));

      setState(() {
        _selectedTime = null;
      });
    }
  }

  Future<bool> _checkAppointmentExistence(
      DateTime selectedDay, TimeOfDay selectedTime) async {
    final firestore = FirebaseFirestore.instance;
    final appointmentDateTime = DateTime(
      selectedDay.year,
      selectedDay.month,
      selectedDay.day,
      selectedTime.hour,
      selectedTime.minute,
    );

    final querySnapshot = await firestore
        .collection('randevular')
        .where('tarih', isEqualTo: Timestamp.fromDate(selectedDay))
        .where('saat', isEqualTo: Timestamp.fromDate(appointmentDateTime))
        .get();

    return querySnapshot.docs.isNotEmpty;
  }

  Future<void> _addAppointment(
      DateTime selectedDay, TimeOfDay selectedTime) async {
    final firestore = FirebaseFirestore.instance;
    final user = FirebaseAuth.instance.currentUser;

    final appointmentDateTime = DateTime(
      selectedDay.year,
      selectedDay.month,
      selectedDay.day,
      selectedTime.hour,
      selectedTime.minute,
    );

    try {
      await firestore.collection('randevular').add({
        'tarih': Timestamp.fromDate(selectedDay),
        'saat': Timestamp.fromDate(appointmentDateTime),
        'doluMu': true,
        'userId': user?.uid,
      });
      setState(() {
        _hasExistingAppointment = true;
      });
    } catch (e) {
      print("Hata: $e");
    }
  }

  Future<void> _deleteAppointment(String appointmentId) async {
    try {
      await FirebaseFirestore.instance
          .collection('randevular')
          .doc(appointmentId)
          .delete();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Randevu başarıyla silindi.'),
        ),
      );
      setState(() {
        _hasExistingAppointment = false;
      });
    } catch (e) {
      print("Hata: $e");
    }
  }
}
