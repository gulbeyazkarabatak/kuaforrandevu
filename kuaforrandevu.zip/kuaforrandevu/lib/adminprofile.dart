import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final currentUser = FirebaseAuth.instance.currentUser;

  String? firstName;
  bool isLoading = true;
  String? errorMessage;

  late TextEditingController _firstNameController;
  late TextEditingController _newPasswordController;

  @override
  void initState() {
    super.initState();
    _firstNameController = TextEditingController();
    _newPasswordController = TextEditingController();
    getUserData();
  }

  Future<void> getUserData() async {
    try {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser!.uid)
          .get();

      if (userDoc.exists) {
        setState(() {
          firstName = userDoc.get('ad');
          _firstNameController.text = firstName ?? '';
          isLoading = false;
        });
      } else {
        setState(() {
          errorMessage = 'Kullanıcı verisi bulunamadı.';
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = 'Veri alınırken bir hata oluştu: $e';
        isLoading = false;
      });
    }
  }

  Future<void> _updateUsernameAndPassword() async {
    final scaffoldMessenger = ScaffoldMessenger.of(context);
    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser!.uid)
          .update({
        'ad': _firstNameController.text,
      });

      if (_newPasswordController.text.isNotEmpty) {
        await currentUser!.updatePassword(_newPasswordController.text);
        // Oturumu yeniden oluştur
        await FirebaseAuth.instance.signOut();
      }

      scaffoldMessenger.showSnackBar(
        const SnackBar(content: Text('Kullanıcı bilgileri güncellendi')),
      );
      setState(() {
        firstName = _firstNameController.text;
      });
    } catch (e) {
      scaffoldMessenger.showSnackBar(
        SnackBar(
            content:
                Text('Kullanıcı bilgileri güncellenirken hata oluştu: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[400],
      appBar: AppBar(
        title: const Text("Profil Sayfası"),
        backgroundColor: Colors.grey[900],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : errorMessage != null
              ? Center(child: Text(errorMessage!))
              : SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const Icon(
                          Icons.person,
                          size: 72,
                        ),
                        TextField(
                          controller: _firstNameController,
                          decoration: const InputDecoration(labelText: 'Ad'),
                        ),
                        TextField(
                          controller: _newPasswordController,
                          decoration:
                              const InputDecoration(labelText: 'Yeni Şifre'),
                          obscureText: true,
                        ),
                        const SizedBox(height: 20),
                        ElevatedButton(
                          onPressed: _updateUsernameAndPassword,
                          child: const Text('Bilgileri Güncelle'),
                        ),
                      ],
                    ),
                  ),
                ),
    );
  }

  @override
  void dispose() {
    _firstNameController.dispose();
    _newPasswordController.dispose();
    super.dispose();
  }
}
