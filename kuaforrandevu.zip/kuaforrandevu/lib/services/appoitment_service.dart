import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class Randevu {
  String id;
  String baslik;
  DateTime tarih;
  TimeOfDay saat;
  String aciklama;

  Randevu({
    required this.id,
    required this.baslik,
    required this.tarih,
    required this.saat,
    required this.aciklama,
  });

  factory Randevu.fromMap(Map<String, dynamic> data, String documentId) {
    return Randevu(
      id: documentId,
      baslik: data['baslik'],
      tarih: (data['tarih'] as Timestamp).toDate(),
      saat: TimeOfDay(
        hour: (data['saat'] as Timestamp).toDate().hour,
        minute: (data['saat'] as Timestamp).toDate().minute,
      ),
      aciklama: data['aciklama'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'baslik': baslik,
      'tarih': Timestamp.fromDate(tarih),
      'saat': Timestamp.fromDate(
          DateTime(tarih.year, tarih.month, tarih.day, saat.hour, saat.minute)),
      'aciklama': aciklama,
    };
  }

  Future<void> randevuEkle(Randevu randevu) async {
    final firestore = FirebaseFirestore.instance;
    try {
      await firestore.collection('randevular').add(randevu.toMap());
    } catch (e) {
      print("Randevu eklenirken hata oluştu: $e");
    }
  }

  Future<void> randevuSil(String randevuId) async {
    final firestore = FirebaseFirestore.instance;
    try {
      await firestore.collection('randevular').doc(randevuId).delete();
    } catch (e) {
      print("Randevu silinirken hata oluştu: $e");
    }
  }

  Stream<List<Randevu>> randevulariGetir(DateTime selectedDay) {
    DateTime start =
        DateTime(selectedDay.year, selectedDay.month, selectedDay.day);
    DateTime end = DateTime(
        selectedDay.year, selectedDay.month, selectedDay.day, 23, 59, 59);

    return FirebaseFirestore.instance
        .collection('randevular')
        .where('tarih', isGreaterThanOrEqualTo: Timestamp.fromDate(start))
        .where('tarih', isLessThanOrEqualTo: Timestamp.fromDate(end))
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) =>
                Randevu.fromMap(doc.data() as Map<String, dynamic>, doc.id))
            .toList());
  }
}
