import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart'; // Firestore ekleniyor

class AuthService {
  final _auth = FirebaseAuth.instance;
  final _firestore = FirebaseFirestore.instance; // Firestore instance eklendi

  Future<User?> createUserWithEmailAndPassword(String name, String surname,
      String email, String password, String text) async {
    try {
      final cred = await _auth.createUserWithEmailAndPassword(
          email: email, password: password);

      if (cred.user != null) {
        // Kullanıcı başarıyla oluşturuldu, Firestore'da kullanıcıya özel bir belge oluşturalım.
        await _firestore.collection('users').doc(cred.user!.uid).set({
          'ad': name,
          'soyad': surname,
          'email': email,
          // Diğer kullanıcı bilgilerini buraya ekleyebilirsiniz
        });
        print("Kullanıcı başarıyla oluşturuldu: ${cred.user}");
      }
      return cred.user;
    } catch (e) {
      print("Kullanıcı oluşturulurken hata oluştu: $e");
      return null;
    }
  }

  Future<User?> signinUserWithEmailAndPassword(
      String email, String password) async {
    try {
      final cred = await _auth.signInWithEmailAndPassword(
          email: email, password: password);

      if (cred.user != null) {
        print("Kullanıcı giriş yaptı: ${cred.user}");
      }
      return cred.user;
    } catch (e) {
      print("Kullanıcı girişi sırasında hata oluştu: $e");
      return null;
    }
  }

  Future<void> signout() async {
    try {
      await _auth.signOut();
    } catch (e) {
      print("Kullanıcı çıkış yaparken hata oluştu: $e");
    }
  }

  Future<void> resetPassword(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
      print("Şifre sıfırlama e-postası gönderildi");
    } catch (e) {
      print("Şifre sıfırlama e-postası gönderilirken hata oluştu: $e");
    }
  }

  onSignout() {}
}
