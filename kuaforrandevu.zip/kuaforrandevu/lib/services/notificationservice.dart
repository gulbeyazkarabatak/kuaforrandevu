import 'package:firebase_messaging/firebase_messaging.dart';

class NotificationServices {
  FirebaseMessaging messaging = FirebaseMessaging.instance;

  void requestNotificationPermissions() async {
    NotificationSettings settings = await messaging.requestPermission(
      alert: true,
      announcement: true,
      badge: true,
      carPlay: true,
      criticalAlert: true,
      provisional: true,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      print('kullanıcı izin verdi');
    } else if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      print('Kullancıı sadece gerekli izinleri verdi');
    } else {
      print('Kullanıcı izinleri vermedi');
    }

    final token = await messaging.getToken();
    print("Cihaz token: $token");
  }
}
