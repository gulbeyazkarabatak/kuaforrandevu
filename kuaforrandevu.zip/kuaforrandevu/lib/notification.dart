import 'package:firebase_messaging/firebase_messaging.dart';

class FirebaseNotificationService {
  late final FirebaseMessaging messaging;
  void SettingNotifications() async {
    await messaging.requestPermission(
      alert: true,
      sound: true,
      badge: true,
    );
  }
}
