import 'package:flutter/material.dart';
import 'package:randevu/mylisttitle.dart';

class MyDrawer extends StatelessWidget {
  final void Function()? onProfileTap;
  final void Function()? onSignOut;
  final void Function()? onAppoitment;

  const MyDrawer({
    Key? key,
    required this.onProfileTap,
    required this.onSignOut,
    required this.onAppoitment,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: Colors.grey[900],
      child: Column(
        children: [
          DrawerHeader(
            child: Icon(
              Icons.person,
              color: Colors.white,
              size: 64,
            ),
          ),
          MyListTile(
            icon: Icons.home,
            text: 'Ana Sayfa',
            onTap: () {
              Navigator.pop(context);
            },
          ),
          MyListTile(
            icon: Icons.person,
            text: 'Profil',
            onTap: () {
              Navigator.pop(context);
              if (onProfileTap != null) {
                onProfileTap!();
              }
            },
          ),
          MyListTile(
            icon: Icons.add,
            text: 'Randevularım',
            onTap: () {
              Navigator.pop(context);
              if (onAppoitment != null) {
                onAppoitment!();
              }
            },
          ),
          MyListTile(
            icon: Icons.logout,
            text: 'Çıkış Yap',
            onTap: () {
              Navigator.pop(context);
              if (onSignOut != null) {
                onSignOut!();
              }
            },
          ),
        ],
      ),
    );
  }
}
