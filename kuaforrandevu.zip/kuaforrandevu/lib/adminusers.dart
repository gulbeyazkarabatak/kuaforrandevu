import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Adminusers extends StatefulWidget {
  const Adminusers({super.key});

  @override
  State<Adminusers> createState() => _AdminusersState();
}

class _AdminusersState extends State<Adminusers> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kullanıcılar'),
      ),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance.collection('users').snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
          var users = snapshot.data?.docs;
          return ListView.builder(
            itemCount: users?.length,
            itemBuilder: (context, index) {
              var userData = users?[index].data() as Map<String, dynamic>?;
              var ad = userData?['ad'];
              var soyad = userData?['soyad'];
              var email = userData?['email'];

              if (ad != null && soyad != null) {
                return ListTile(
                  title: Text('$ad $soyad'),
                  subtitle: Text(email ?? ''),
                );
              } else {
                return const SizedBox.shrink();
              }
            },
          );
        },
      ),
    );
  }
}
