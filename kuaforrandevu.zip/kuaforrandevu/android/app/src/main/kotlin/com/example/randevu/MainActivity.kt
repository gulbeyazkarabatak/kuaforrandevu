package com.example.randevu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
